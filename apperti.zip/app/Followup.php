<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Followup extends Model
{
    protected $table = 'followup';
    protected $fillable = ['aplikan_id','keterangan','user_id','type'];

}
